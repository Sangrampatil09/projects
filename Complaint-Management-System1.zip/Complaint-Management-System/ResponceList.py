from tkinter import *
from tkinter.ttk import *
import sqlite3

from configdb import ConnectionDatabase


class ResponceList:
    def __init__(self):
        self.connectionDB = ConnectionDatabase()
        self.connectionDB.row_factory = sqlite3.Row
        self.root = Tk()
        self.root.title('List of Responce')
        self.tree = Treeview(self.root)
        self.tree.pack()
        self.tree.heading('#0', text='ID')
        self.tree.configure(column=('#Name', '#Complaint', '#Responce'))
        self.tree.heading('#Name', text='name')
        self.tree.heading('#Complaint', text='complaint')
        self.tree.heading('#Responce', text='responce')
        self.tree.column('#0', stretch=NO, minwidth=0, width=100)
        self.tree.column('#1', stretch=NO, minwidth=0, width=150)
        self.tree.column('#2', stretch=NO, minwidth=0, width=300)
        self.tree.column('#3', stretch=NO, minwidth=0, width=300)
        cursor = self.connectionDB.ListRequestRes()
        for row in cursor:
            self.tree.insert('', 'end', '#{}'.format(row['ID']), text=row['ID'])
            self.tree.set('#{}'.format(row['ID']), '#Name', row['name'])
            self.tree.set('#{}'.format(row['ID']), '#Complaint', row['complaint'])
            self.tree.set('#{}'.format(row['ID']), '#Responce', row['responce'])
        self.tree.bind("<Double-1>", self.OnDoubleClick)
        self.root.mainloop()

    def OnDoubleClick(self, event):
        item = self.tree.selection()[0]
        print("you clicked on", self.tree.item(item,"text"))
        
