from tkinter import *
from tkinter.ttk import *
import sqlite3

from configdb import ConnectionDatabase


class ComplaintListing:
    def __init__(self):
        self.connectionDB = ConnectionDatabase()
        self.connectionDB.row_factory = sqlite3.Row
        self.root = Tk()
        self.root.title('List of Complaints')
        self.tree = Treeview(self.root)
        self.tree.pack()
        self.tree.heading('#0', text='ID')
        self.tree.configure(column=('#FirstName', '#LastName', '#Address', '#Gender', '#Comment'))
        self.tree.heading('#FirstName', text='First Name')
        self.tree.heading('#LastName', text='Last Name')
        self.tree.heading('#Address', text='Address')
        self.tree.heading('#Gender', text='Gender')
        self.tree.heading('#Comment', text='Comment')
        self.tree.column('#0', stretch=NO, minwidth=0, width=100)
        self.tree.column('#1', stretch=NO, minwidth=0, width=100)
        self.tree.column('#2', stretch=NO, minwidth=0, width=100)
        self.tree.column('#3', stretch=NO, minwidth=0, width=100)
        self.tree.column('#4', stretch=NO, minwidth=0, width=100)
        self.tree.column('#5', stretch=NO, minwidth=0, width=300)
        self.cursor = self.connectionDB.ListRequest()
        for row in self.cursor:
            self.tree.insert('', 'end', '#{}'.format(row['ID']), text=row['ID'])
            self.tree.set('#{}'.format(row['ID']), '#FirstName', row['FirstName'])
            self.tree.set('#{}'.format(row['ID']), '#LastName', row['LastName'])
            self.tree.set('#{}'.format(row['ID']), '#Address', row['Address'])
            self.tree.set('#{}'.format(row['ID']), '#Gender', row['Gender'])
            self.tree.set('#{}'.format(row['ID']), '#Comment', row['Comment'])
        self.tree.bind("<Double-1>", self.OnDoubleClick)
        self.root.mainloop()

    def OnDoubleClick(self, event):
        item = self.tree.selection()[0]
        from ResponceTake import ResponceTake
        enterresponce = ResponceTake(self.tree.item(item)['values'][4])

