
from tkinter import *
from tkinter.ttk import *
from tkinter.messagebox import *

from ResponceList import ResponceList
from configdb import ConnectionDatabase

#Config
class ResponceTake():
    def __init__(self,complaint) -> None:
        conn = ConnectionDatabase()
        root = Tk()
        root.geometry('550x350')
        root.title('Responce of Complaint')
        root.configure(bg='grey')

        #Style


        style = Style()
        style.theme_use('classic')
        for styles in ['TLabel', 'TButton', 'TRadioButton']:
            style.configure(styles, bg='blue')


        labels = ['Name', 'Complaint', 'Responce']
        for i in range(3):
            Label(root, text=labels[i]).grid(row=i, column=0, padx=10, pady=10)

        ButtonSubmit = Button(root, text='Submit Now')
        ButtonSubmit.grid(row=5, column=2)

        # Entries
        Name = Entry(root, width=40, font=('Arial', 14))
        Name.grid(row=0, column=1, columnspan=2)


        comment = Label(root,text=complaint,font='10').grid(row=1,column=1,columnspan=2)

        
        responce = Text(root, width=40, height=5, font=('Arial', 14))
        responce.grid(row=2, column=1, columnspan=2, padx=10, pady=10)


        def SaveData():
            message = conn.AddResponce(Name.get(), complaint, responce.get(1.0, 'end'))
            Name.delete(0,'end')
            responce.delete(0, 'end')
            showinfo(title='Add Information', message=message)
            return

        ButtonSubmit.config(command=SaveData)

