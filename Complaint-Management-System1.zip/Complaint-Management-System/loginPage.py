from tkinter import *
from functools import partial
from complaintListing import ComplaintListing

def validateLogin(username, password):
	if('admin'==username.get() and 'admin'==password.get()):
		listrequest = ComplaintListing()
	elif('student'==username.get() and password.get()=='student'):
		from ComplaintSystemMain import ComplaintSystemMain
		maincomplain = ComplaintSystemMain()
	else:
		return
	

#window
tkWindow = Tk()  
tkWindow.geometry('400x150')  
tkWindow.title('Tkinter Login Form - pythonexamples.org')

usernameLabel = Label(tkWindow, text="Login Page",font='Times 18').grid(row=0, column=2)

#username label and text entry box
usernameLabel = Label(tkWindow, text="User Name :",font='6').grid(row=2, column=1)
username = StringVar()
usernameEntry = Entry(tkWindow, textvariable=username,font='6').grid(row=2, column=2)  

#password label and password entry box
passwordLabel = Label(tkWindow,text="Password : ",font='6').grid(row=3, column=1)  
password = StringVar()
passwordEntry = Entry(tkWindow, textvariable=password, show='*',font='6').grid(row=3, column=2)  

validateLogin = partial(validateLogin, username, password)

#login button
loginButton = Button(tkWindow, text="Login", command=validateLogin).grid(row=4, column=2)  

tkWindow.mainloop()