
import sqlite3

class ConnectionDatabase:
	def __init__(self):
		self._db = sqlite3.connect('complaintDB.db')
		self._db.row_factory = sqlite3.Row
		self._db.execute('create table if not exists complainTable(ID integer primary key autoincrement, FirstName varchar(255), LastName varchar(255), Address Text, Gender varchar(255), Comment text)')
		self._db.commit()
		self._db.execute('create table if not exists responceTable(ID integer primary key autoincrement, name varchar(30),complaint varchar(200),responce varchar(200))')
		self._db.commit()
	def Add(self,firstname,lastname,address, gender,comment):
		self._db.execute('insert into complainTable (FirstName, LastName, Address, Gender, Comment) values (?,?,?,?,?)', (firstname, lastname, address, gender, comment))
		self._db.commit()
		return 'Your complaint has been submitted.'
	
	def ListRequest(self):
		cursor = self._db.execute('select * from complainTable')
		return cursor
	
	def AddResponce(self,name,complaint,responce):
		self._db.execute('insert into responceTable (name,complaint,responce) values (?,?,?)',(name,complaint,responce))
		self._db.commit()

	def ListRequestRes(self):
		cursor = self._db.execute('select * from responceTable')
		return cursor
